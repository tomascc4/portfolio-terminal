"""Portfolio dashboard utilities."""
